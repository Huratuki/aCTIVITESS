﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Payroll_App
{
    public partial class frm_Employee : Form
    {
        private string loggedInUsername;
        private int employeeNo;

        public frm_Employee()
        {
            InitializeComponent();
        }

        // Constructor to accept logged-in username
        public frm_Employee(string loggedInUsername)
        {
            InitializeComponent();
            this.loggedInUsername = loggedInUsername;
            LoadPayrollInfo(); // Load payroll-related information upon initialization
        }

        private void LoadPayrollInfo()
        {
            // Load payroll-related information based on the logged-in username
            // Example: You can fetch payroll data from the database using the username and display it on the form
            // For demonstration purposes, let's just display a message showing the logged-in username
            MessageBox.Show("Welcome, This was created by Cabuhat Lavarez Trumata! " ); // You can replace this with your actual data retrieval logic
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                int lastEmployeeNo = GetLastEmployeeNo();

                // Increment the employee number for the new entry
                employeeNo = lastEmployeeNo + 1;

                // Retrieve values from TextBoxes
                decimal rate = decimal.Parse(txtRate.Text); // Rate per day
                decimal days = decimal.Parse(txtDays.Text); // Number of days worked
                decimal overtimeHours = decimal.Parse(txtOvertime.Text); // Number of overtime hours worked

                // Calculate gross pay
                decimal gross = rate * days + overtimeHours; // Total gross pay including overtime

                // Calculate tax
                decimal taxRate = 0.15m; // Tax rate of 15%
                decimal tax = gross * taxRate; // Calculate tax

                // Calculate SSS contribution
                decimal sssRate = 0.05m; // SSS contribution rate of 5%
                decimal sss = gross * sssRate; // Calculate SSS contribution

                // Calculate Pagibig contribution
                decimal pagibigRate = 0.05m; // Pagibig contribution rate of 5%
                decimal pagibig = gross * pagibigRate; // Calculate Pagibig contribution

                // Calculate PhilHealth contribution (assuming a fixed rate)
                decimal philhealthRate = 100m; // Fixed PhilHealth contribution rate (replace with actual rate if available)
                decimal philhealth = philhealthRate; // PhilHealth contribution

                // Calculate total deduction
                decimal deduction = tax + sss + pagibig + philhealth; // Total deduction

                // Calculate net pay
                decimal netpay = gross - deduction; // Net pay after deductions

                // Assign the calculated values to the corresponding TextBoxes
                txtGross.Text = gross.ToString();
                txtTax.Text = tax.ToString();
                txtsss.Text = sss.ToString();
                txtPagibig.Text = pagibig.ToString();
                txtPhil.Text = philhealth.ToString();
                txtDeduc.Text = deduction.ToString();
                txtNetpay.Text = netpay.ToString();
                txtEmployeeno.Text = employeeNo.ToString();

                // Your connection string to SQL Server database
                string connectionString = "Data Source=desktop-bb5j2kg\\sqlexpress;Initial Catalog=payroll;User ID=robins;Password=1234";

                // SQL INSERT statement
                string insertQuery = "INSERT INTO tbl_PayroLL (EmployeeNo, Rate, Days, Overtime, Gross, Tax, SSS, Pagibig, Philhealth, Deduction, Netpay) " +
                                     "VALUES (@EmployeeNo, @Rate, @Days, @Overtime, @Gross, @Tax, @SSS, @Pagibig, @Philhealth, @Deduction, @Netpay)";

                // Create connection and command objects
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Set parameter values from TextBoxes and calculated values
                    command.Parameters.AddWithValue("@Rate", rate);
                    command.Parameters.AddWithValue("@Days", days);
                    command.Parameters.AddWithValue("@Overtime", overtimeHours);
                    command.Parameters.AddWithValue("@Gross", gross);
                    command.Parameters.AddWithValue("@Tax", tax);
                    command.Parameters.AddWithValue("@SSS", sss);
                    command.Parameters.AddWithValue("@Pagibig", pagibig);
                    command.Parameters.AddWithValue("@Philhealth", philhealth);
                    command.Parameters.AddWithValue("@Deduction", deduction);
                    command.Parameters.AddWithValue("@Netpay", netpay);
                    command.Parameters.AddWithValue("@EmployeeNo", employeeNo);

                    // Open the connection
                    connection.Open();

                    // Execute the INSERT statement
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numerical values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private int GetLastEmployeeNo()
        {
            int lastEmployeeNo = 0;
            try
            {
                // Your connection string
                string connectionString = "Data Source=desktop-bb5j2kg\\sqlexpress;Initial Catalog=payroll;User ID=robins;Password=1234";

                // SQL query to select the last used employee number from the table
                string query = "SELECT MAX(EmployeeNo) FROM tbl_PayroLL";

                // Create connection and command objects
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Open the connection
                    connection.Open();

                    // Execute the query and get the result
                    object result = command.ExecuteScalar();

                    // Check if the result is not null and convert it to an integer
                    if (result != null && result != DBNull.Value)
                    {
                        lastEmployeeNo = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lastEmployeeNo;
        }
        private void btnsave_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Your connection string
                string connectionString = "Data Source=desktop-bb5j2kg\\sqlexpress;Initial Catalog=payroll;User ID=robins;Password=1234";

                // SQL query to select all data from the table, sorted by EmployeeNo in descending order
                string query = "SELECT * FROM tbl_PayroLL ORDER BY EmployeeNo DESC";

                // Create a DataTable to store the data
                DataTable dataTable = new DataTable();

                // Create a SqlDataAdapter to execute the query and fill the DataTable
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    // Open the connection
                    connection.Open();

                    // Fill the DataTable with data from the database
                    adapter.Fill(dataTable);
                }

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Optional: Handle cell click events if needed
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear all TextBoxes
            txtRate.Text = "";
            txtDays.Text = "";
            txtOvertime.Text = "";
            txtGross.Text = "";
            txtTax.Text = "";
            txtsss.Text = "";
            txtPagibig.Text = "";
            txtPhil.Text = "";
            txtDeduc.Text = "";
            txtNetpay.Text = "";
            txtEmployeeno.Text = "";
        }
    }
}
