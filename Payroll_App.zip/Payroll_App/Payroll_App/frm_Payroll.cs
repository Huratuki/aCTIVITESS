﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ticket_management;

namespace Payroll_App
{
    public partial class frm_Payroll : Form
    {
        private string username, password;
        private int errorCount;
        Class1 login = new Class1("DESKTOP-BB5J2KG\\SQLEXPRESS", "PayroLL", "robins", "1234");

        public frm_Payroll()
        {
            InitializeComponent();
        }

        private void countErrors()
        {
            errorCount = 0;
            foreach (Control c in errorProvider1.ContainerControl.Controls)
            {
                if (!(string.IsNullOrEmpty(errorProvider1.GetError(c))))
                {
                    errorCount++;
                }
            }
        }

        public void validateUsername()
        {
            if (string.IsNullOrEmpty(txtusername.Text))
            {
                errorProvider1.SetError(txtusername, "Input is empty");
            }
            else
            {
                errorProvider1.SetError(txtusername, "");
                username = txtusername.Text;
            }
        }

        public void validatePassword()
        {
            if (string.IsNullOrEmpty(txtpassword.Text))
            {
                errorProvider1.SetError(txtpassword, "Input is empty");
            }
            else
            {
                errorProvider1.SetError(txtpassword, "");
                password = txtpassword.Text;
            }
        }

        private void chkshow_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void frm_Payroll_Load(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            validateUsername();
            validatePassword();
            if (errorCount == 0)
            {
                try
                {
                    DataTable dt = login.GetData("SELECT * FROM tbl_accounts WHERE userName = '" + username + "' AND passWord = '"
                        + password + "' AND status = 'ACTIVE'");
                    if (dt.Rows.Count > 0)
                    {
                        // Get the username
                        string loggedInUsername = dt.Rows[0]["userName"].ToString();

                        // Initialize the employee form with the logged-in username
                        frm_Employee frm_Employee = new frm_Employee(loggedInUsername);

                        // Show the employee form and hide the login form
                        frm_Employee.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Username or Password", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error on login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
